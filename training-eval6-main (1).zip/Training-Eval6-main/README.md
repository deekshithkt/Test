# palcLib
common utilities and libraries

Includes common OS type definitions in `cmn/ostypes.h`.
