# Single Linked List (SLL) API Documentation

## Overview
The Single Linked List (SLL) module provides a generic, efficient implementation of a singly-linked list data structure. It uses an intrusive design pattern where the list node is embedded within the data structure, allowing for zero-allocation list operations.

## Data Structures

### SLLNode
```c
typedef struct SLLNode {
    struct SLLNode *ps_next;
} SLLNode;
```
**Description**: Basic node structure that should be embedded in user-defined structures.
- `ps_next`: Pointer to the next node in the list

### SLLHeader
```c
typedef struct {
    SLLNode *ps_head;
    SLLNode *ps_tail;
    u4       u4_cnt;
    u4       u4_offset;
} SLLHeader;
```
**Description**: List header that maintains the list state.
- `ps_head`: Pointer to the first node in the list
- `ps_tail`: Pointer to the last node in the list
- `u4_cnt`: Current number of nodes in the list
- `u4_offset`: Offset of the SLLNode member within the containing structure

## API Functions

### sll_init
```c
void sll_init(SLLHeader *hdr, size_t offset);
```
**Description**: Initializes a new single linked list.

**Parameters**:
- `hdr`: Pointer to the SLLHeader structure to initialize
- `offset`: Offset of the SLLNode member within the containing structure

**Example**:
```c
typedef struct {
    int data;
    SLLNode node;
} MyData;

SLLHeader list;
sll_init(&list, offsetof(MyData, node));
```

### sll_insert_front
```c
void sll_insert_front(SLLHeader *hdr, void *entry);
```
**Description**: Inserts a new entry at the beginning of the list.

**Parameters**:
- `hdr`: Pointer to the list header
- `entry`: Pointer to the entry to insert (must contain an embedded SLLNode)

**Time Complexity**: O(1)

### sll_insert_end
```c
void sll_insert_end(SLLHeader *hdr, void *entry);
```
**Description**: Inserts a new entry at the end of the list.

**Parameters**:
- `hdr`: Pointer to the list header
- `entry`: Pointer to the entry to insert (must contain an embedded SLLNode)

**Time Complexity**: O(1)

### sll_remove
```c
void sll_remove(SLLHeader *hdr, void *entry);
```
**Description**: Removes a specific entry from the list.

**Parameters**:
- `hdr`: Pointer to the list header
- `entry`: Pointer to the entry to remove

**Time Complexity**: O(n) - requires traversal to find the entry

### sll_pop_front
```c
void* sll_pop_front(SLLHeader *hdr);
```
**Description**: Removes and returns the first entry in the list.

**Parameters**:
- `hdr`: Pointer to the list header

**Returns**: Pointer to the removed entry, or NULL if the list is empty

**Time Complexity**: O(1)

### sll_find
```c
void* sll_find(SLLHeader *hdr, bool (*cmp)(void *entry, void *arg), void *arg);
```
**Description**: Searches for an entry in the list using a custom comparison function.

**Parameters**:
- `hdr`: Pointer to the list header
- `cmp`: Comparison function that returns true when the desired entry is found
- `arg`: User-defined argument passed to the comparison function

**Returns**: Pointer to the found entry, or NULL if not found

**Time Complexity**: O(n)

**Example**:
```c
bool find_by_id(void *entry, void *arg) {
    MyData *data = entry;
    int *target_id = arg;
    return data->id == *target_id;
}

int id_to_find = 42;
MyData *found = sll_find(&list, find_by_id, &id_to_find);
```

## Macros

### SLL_COUNT
```c
#define SLL_COUNT(hdr) ((hdr)->u4_cnt)
```
**Description**: Returns the number of entries in the list.

**Parameters**:
- `hdr`: Pointer to the list header

**Returns**: Number of entries (u4)

### SLL_FIRST
```c
#define SLL_FIRST(hdr) ((hdr)->ps_head)
```
**Description**: Returns the first node in the list.

**Parameters**:
- `hdr`: Pointer to the list header

**Returns**: Pointer to the first SLLNode, or NULL if empty

### SLL_LAST
```c
#define SLL_LAST(hdr) ((hdr)->ps_tail)
```
**Description**: Returns the last node in the list.

**Parameters**:
- `hdr`: Pointer to the list header

**Returns**: Pointer to the last SLLNode, or NULL if empty

### SLL_FOREACH
```c
#define SLL_FOREACH(hdr, iter) \
    for ((iter) = (hdr)->ps_head; (iter) != NULL; (iter) = (iter)->ps_next)
```
**Description**: Iterates through all nodes in the list.

**Parameters**:
- `hdr`: Pointer to the list header
- `iter`: Iterator variable of type SLLNode*

**Example**:
```c
SLLNode *node;
SLL_FOREACH(&list, node) {
    MyData *data = SLL_ENTRY(node, MyData, node);
    printf("Data: %d\n", data->value);
}
```

### SLL_ENTRY
```c
#define SLL_ENTRY(node, type, member) \
    ((type *)((char *)(node) - offsetof(type, member)))
```
**Description**: Converts a SLLNode pointer to its containing structure.

**Parameters**:
- `node`: Pointer to the SLLNode
- `type`: Type of the containing structure
- `member`: Name of the SLLNode member within the structure

**Returns**: Pointer to the containing structure

**Example**:
```c
SLLNode *node = SLL_FIRST(&list);
MyData *data = SLL_ENTRY(node, MyData, node);
```

## Usage Example

```c
#include "utlsll.h"
#include <stdio.h>

typedef struct {
    int id;
    char name[32];
    SLLNode node;
} Person;

int main() {
    SLLHeader people_list;
    
    // Initialize the list
    sll_init(&people_list, offsetof(Person, node));
    
    // Create and insert people
    Person p1 = {1, "Alice", {0}};
    Person p2 = {2, "Bob", {0}};
    Person p3 = {3, "Charlie", {0}};
    
    sll_insert_end(&people_list, &p1);
    sll_insert_end(&people_list, &p2);
    sll_insert_front(&people_list, &p3);
    
    // Print list count
    printf("List contains %u people\n", SLL_COUNT(&people_list));
    
    // Iterate through the list
    SLLNode *node;
    SLL_FOREACH(&people_list, node) {
        Person *p = SLL_ENTRY(node, Person, node);
        printf("ID: %d, Name: %s\n", p->id, p->name);
    }
    
    // Remove Bob
    sll_remove(&people_list, &p2);
    
    // Pop first person
    Person *first = sll_pop_front(&people_list);
    if (first) {
        printf("Popped: %s\n", first->name);
    }
    
    return 0;
}
```

## Notes
- The SLL implementation uses an intrusive design pattern, meaning the list node must be embedded within your data structure
- All operations maintain head and tail pointers for efficient operations at both ends
- The list does not manage memory allocation/deallocation - the caller is responsible for managing the lifetime of list entries
- Thread safety is not provided - external synchronization is required for concurrent access