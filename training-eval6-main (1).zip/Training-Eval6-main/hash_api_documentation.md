# Hash Table API Documentation

## Overview
The Hash Table module provides a generic, efficient implementation of a hash table data structure using chaining for collision resolution. It builds on top of the Doubly Linked List (DLL) module, using DLL for each bucket to handle collisions. The implementation uses an intrusive design pattern where nodes are embedded within user data structures.

## Data Structures

### HashTable
```c
typedef struct {
    DLLHeader *buckets;
    size_t bucket_count;
    size_t offset;
    size_t (*hash_func)(void *entry, size_t bucket_count);
    bool (*key_eq_func)(void *entry, void *key);
} HashTable;
```
**Description**: Main hash table structure that manages buckets and operations.
- `buckets`: Array of DLLHeaders, each representing a bucket for collision resolution
- `bucket_count`: Number of buckets in the hash table
- `offset`: Offset of the DLLNode member within the containing structure
- `hash_func`: User-provided hash function
- `key_eq_func`: User-provided key comparison function

## API Functions

### hash_table_init
```c
bool hash_table_init(HashTable *ht, size_t bucket_count, size_t offset,
                     size_t (*hash_func)(void *, size_t),
                     bool (*key_eq_func)(void *, void *));
```
**Description**: Initializes a new hash table with specified parameters.

**Parameters**:
- `ht`: Pointer to the HashTable structure to initialize
- `bucket_count`: Number of buckets to allocate
- `offset`: Offset of the DLLNode member within the containing structure
- `hash_func`: Function that computes hash value for an entry
- `key_eq_func`: Function that compares an entry with a key

**Returns**: true on success, false if memory allocation fails

**Example**:
```c
typedef struct {
    int id;
    char name[32];
    DLLNode node;
} User;

size_t user_hash(void *entry, size_t bucket_count) {
    User *u = (User *)entry;
    return (size_t)(u->id) % bucket_count;
}

bool user_key_eq(void *entry, void *key) {
    User *u = (User *)entry;
    int *id = (int *)key;
    return u->id == *id;
}

HashTable users;
if (!hash_table_init(&users, 100, offsetof(User, node), user_hash, user_key_eq)) {
    // Handle initialization failure
}
```

### hash_table_insert
```c
void hash_table_insert(HashTable *ht, void *entry);
```
**Description**: Inserts a new entry into the hash table.

**Parameters**:
- `ht`: Pointer to the hash table
- `entry`: Pointer to the entry to insert (must contain an embedded DLLNode)

**Time Complexity**: O(1) average case, O(n) worst case with poor hash distribution

**Note**: Does not check for duplicates. The same entry can be inserted multiple times.

### hash_table_find
```c
void* hash_table_find(HashTable *ht, void *key);
```
**Description**: Searches for an entry in the hash table using the provided key.

**Parameters**:
- `ht`: Pointer to the hash table
- `key`: Pointer to the key to search for

**Returns**: Pointer to the found entry, or NULL if not found

**Time Complexity**: O(1) average case, O(n) worst case

**Example**:
```c
int user_id = 42;
User *found = hash_table_find(&users, &user_id);
if (found) {
    printf("Found user: %s\n", found->name);
}
```

### hash_table_remove
```c
void hash_table_remove(HashTable *ht, void *entry);
```
**Description**: Removes a specific entry from the hash table.

**Parameters**:
- `ht`: Pointer to the hash table
- `entry`: Pointer to the entry to remove

**Time Complexity**: O(1) - direct removal without search

**Note**: The entry must be in the hash table. Removing an entry not in the table results in undefined behavior.

### hash_table_destroy
```c
void hash_table_destroy(HashTable *ht);
```
**Description**: Destroys the hash table and frees allocated bucket memory.

**Parameters**:
- `ht`: Pointer to the hash table to destroy

**Note**: This only frees the bucket array, not the entries themselves. Users must manage entry memory separately.

### hash_table_entry_count
```c
size_t hash_table_entry_count(HashTable *ht);
```
**Description**: Returns the total number of entries in the hash table.

**Parameters**:
- `ht`: Pointer to the hash table

**Returns**: Total number of entries across all buckets

**Time Complexity**: O(n) where n is the number of buckets

### hash_table_print_stats
```c
void hash_table_print_stats(HashTable *ht);
```
**Description**: Prints statistical information about the hash table to stdout.

**Parameters**:
- `ht`: Pointer to the hash table

**Output**: Prints bucket count, used buckets, collisions, average/min/max entries per bucket

**Example Output**:
```
HashTable Stats: buckets=100 used=75 collisions=10 avg=0.85 min=0 max=3
```

## Macros

### HASH_TABLE_BUCKET_COUNT
```c
#define HASH_TABLE_BUCKET_COUNT(ht) ((ht)->bucket_count)
```
**Description**: Returns the number of buckets in the hash table.

**Parameters**:
- `ht`: Pointer to the hash table

**Returns**: Number of buckets (size_t)

### HASH_TABLE_FOREACH_ALL
```c
#define HASH_TABLE_FOREACH_ALL(ht, bkt, iter) \
    for (size_t bkt = 0; bkt < (ht)->bucket_count; bkt++) \
        for ((iter) = (ht)->buckets[bkt].ps_head; (iter) != NULL; (iter) = (iter)->ps_next)
```
**Description**: Iterates through all entries in all buckets of the hash table.

**Parameters**:
- `ht`: Pointer to the hash table
- `bkt`: Bucket index variable (size_t)
- `iter`: Iterator variable of type DLLNode*

**Example**:
```c
size_t bucket;
DLLNode *node;
HASH_TABLE_FOREACH_ALL(&users, bucket, node) {
    User *user = DLL_ENTRY(node, User, node);
    printf("Bucket %zu: User ID=%d, Name=%s\n", bucket, user->id, user->name);
}
```

## Usage Example

```c
#include "utlhash.h"
#include <stdio.h>
#include <string.h>

typedef struct {
    int id;
    char email[64];
    int age;
    DLLNode node;
} Account;

// Hash function based on ID
size_t account_hash(void *entry, size_t bucket_count) {
    Account *acc = (Account *)entry;
    return (size_t)(acc->id) % bucket_count;
}

// Key comparison function
bool account_key_eq(void *entry, void *key) {
    Account *acc = (Account *)entry;
    int *id = (int *)key;
    return acc->id == *id;
}

int main() {
    HashTable accounts;
    
    // Initialize hash table with 50 buckets
    if (!hash_table_init(&accounts, 50, offsetof(Account, node), 
                         account_hash, account_key_eq)) {
        printf("Failed to initialize hash table\n");
        return 1;
    }
    
    // Create and insert accounts
    Account acc1 = {101, "alice@email.com", 25, {0}};
    Account acc2 = {202, "bob@email.com", 30, {0}};
    Account acc3 = {303, "charlie@email.com", 35, {0}};
    
    hash_table_insert(&accounts, &acc1);
    hash_table_insert(&accounts, &acc2);
    hash_table_insert(&accounts, &acc3);
    
    // Find an account
    int search_id = 202;
    Account *found = hash_table_find(&accounts, &search_id);
    if (found) {
        printf("Found account: ID=%d, Email=%s, Age=%d\n", 
               found->id, found->email, found->age);
    }
    
    // Print statistics
    hash_table_print_stats(&accounts);
    
    // Count total entries
    printf("Total accounts: %zu\n", hash_table_entry_count(&accounts));
    
    // Remove an account
    hash_table_remove(&accounts, &acc2);
    
    // Iterate through all entries
    printf("\nAll accounts:\n");
    size_t bucket;
    DLLNode *node;
    HASH_TABLE_FOREACH_ALL(&accounts, bucket, node) {
        Account *acc = DLL_ENTRY(node, Account, node);
        printf("  ID=%d, Email=%s (bucket %zu)\n", acc->id, acc->email, bucket);
    }
    
    // Cleanup
    hash_table_destroy(&accounts);
    
    return 0;
}
```

## Design Considerations

### Hash Function Requirements
The user-provided hash function should:
- Take an entry pointer and bucket count as parameters
- Return a value between 0 and (bucket_count - 1)
- Distribute entries uniformly across buckets for best performance
- Be deterministic (same input always produces same output)

### Key Comparison Function Requirements
The user-provided key comparison function should:
- Take an entry pointer and a key pointer as parameters
- Return true if the entry matches the key, false otherwise
- Handle the key type appropriately (the key type is user-defined)

### Collision Resolution
- Uses chaining with doubly linked lists for collision resolution
- Each bucket is a DLL that can hold multiple entries with the same hash value
- Performance degrades to O(n) for operations in buckets with many collisions

### Load Factor Considerations
- No automatic resizing is provided
- Users should choose bucket count based on expected number of entries
- Recommended load factor: 0.75 (e.g., 100 buckets for ~75 entries)
- Use `hash_table_print_stats()` to monitor distribution and collisions

## Notes
- The hash table uses an intrusive design - DLLNode must be embedded in your data structure
- Memory for entries is not managed by the hash table - users handle allocation/deallocation
- The implementation is not thread-safe - external synchronization required for concurrent access
- Duplicate keys are allowed - `hash_table_find()` returns the first match
- The hash table maintains no ordering of entries
- Iteration order is not guaranteed and may change between operations