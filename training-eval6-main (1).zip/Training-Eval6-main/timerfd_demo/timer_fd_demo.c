// timerfd_two_select.c
// Demo: two timerfds (2s & 3s intervals) using select(), with timestamps & debug logs.

#define _GNU_SOURCE
#include <sys/timerfd.h>
#include <sys/select.h>
#include <unistd.h>
#include <inttypes.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define INFO(fmt, ...)  fprintf(stdout, "[INFO]  " fmt "\n", ##__VA_ARGS__)
#define DBG(fmt, ...)   fprintf(stdout, "[DEBUG] " fmt " (%s:%d)\n", ##__VA_ARGS__, __FILE__, __LINE__)
#define ERR(fmt, ...)   fprintf(stderr, "[ERROR] " fmt " (errno=%d: %s)\n", ##__VA_ARGS__, errno, strerror(errno))

static void now_str(char *buf, size_t len) {
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    struct tm tm;
    localtime_r(&ts.tv_sec, &tm);
    snprintf(buf, len, "%04d-%02d-%02d %02d:%02d:%02d.%03ld",
             tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
             tm.tm_hour, tm.tm_min, tm.tm_sec, ts.tv_nsec / 1000000);
}

int main(void) {
    char tsbuf[64];

    INFO("Starting two-timerfd + select() demo");

    // --- Create two timerfds ---
    int tfd_a = timerfd_create(CLOCK_MONOTONIC, 0);
    int tfd_b = timerfd_create(CLOCK_MONOTONIC, 0);
    if (tfd_a == -1 || tfd_b == -1) {
        ERR("timerfd_create failed");
        return EXIT_FAILURE;
    }

    // --- Configure Timer-A: every 2 seconds ---
    struct itimerspec its_a = {
        .it_value = {2, 0},
        .it_interval = {2, 0},
    };
    // --- Configure Timer-B: every 3 seconds ---
    struct itimerspec its_b = {
        .it_value = {3, 0},
        .it_interval = {3, 0},
    };

    DBG("Arming Timer-A (2s interval)");
    if (timerfd_settime(tfd_a, 0, &its_a, NULL) == -1) {
        ERR("timerfd_settime for Timer-A failed");
        return EXIT_FAILURE;
    }

    DBG("Arming Timer-B (3s interval)");
    if (timerfd_settime(tfd_b, 0, &its_b, NULL) == -1) {
        ERR("timerfd_settime for Timer-B failed");
        return EXIT_FAILURE;
    }

    INFO("Timers armed. Waiting with select(). (Ctrl+C to stop)");

    int total_ticks = 0;
    while (total_ticks < 30) {
        fd_set rfds;
        FD_ZERO(&rfds);
        FD_SET(tfd_a, &rfds);
        FD_SET(tfd_b, &rfds);
        int maxfd = (tfd_a > tfd_b ? tfd_a : tfd_b);

        int rc = select(maxfd + 1, &rfds, NULL, NULL, NULL);
        if (rc == -1) {
            if (errno == EINTR) continue;
            ERR("select() failed");
            break;
        }

        uint64_t expirations = 0;

        if (FD_ISSET(tfd_a, &rfds)) {
            if (read(tfd_a, &expirations, sizeof(expirations)) == sizeof(expirations)) {
                now_str(tsbuf, sizeof(tsbuf));
                INFO("Timer-A fired (%" PRIu64 "x) at %s", expirations, tsbuf);
                total_ticks++;
            }
        }

        if (FD_ISSET(tfd_b, &rfds)) {
            if (read(tfd_b, &expirations, sizeof(expirations)) == sizeof(expirations)) {
                now_str(tsbuf, sizeof(tsbuf));
                INFO("Timer-B fired (%" PRIu64 "x) at %s", expirations, tsbuf);
                total_ticks++;
            }
        }
    }

    DBG("Disarming and closing timers");
    struct itimerspec disarm = {0};
    timerfd_settime(tfd_a, 0, &disarm, NULL);
    timerfd_settime(tfd_b, 0, &disarm, NULL);
    close(tfd_a);
    close(tfd_b);

    INFO("Demo complete. Exiting cleanly.");
    return 0;
}

