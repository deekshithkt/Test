# Doubly Linked List (DLL) API Documentation

## Overview
The Doubly Linked List (DLL) module provides a generic, efficient implementation of a doubly-linked list data structure. It uses an intrusive design pattern where the list node is embedded within the data structure, allowing for zero-allocation list operations and bidirectional traversal.

## Data Structures

### DLLNode
```c
typedef struct DLLNode {
    struct DLLNode *ps_prev;
    struct DLLNode *ps_next;
} DLLNode;
```
**Description**: Basic node structure that should be embedded in user-defined structures.
- `ps_prev`: Pointer to the previous node in the list
- `ps_next`: Pointer to the next node in the list

### DLLHeader
```c
typedef struct {
    DLLNode *ps_head;
    DLLNode *ps_tail;
    u4       u4_cnt;
    u4       u4_offset;
} DLLHeader;
```
**Description**: List header that maintains the list state.
- `ps_head`: Pointer to the first node in the list
- `ps_tail`: Pointer to the last node in the list
- `u4_cnt`: Current number of nodes in the list
- `u4_offset`: Offset of the DLLNode member within the containing structure

## API Functions

### dll_init
```c
void dll_init(DLLHeader *hdr, size_t offset);
```
**Description**: Initializes a new doubly linked list.

**Parameters**:
- `hdr`: Pointer to the DLLHeader structure to initialize
- `offset`: Offset of the DLLNode member within the containing structure

**Example**:
```c
typedef struct {
    int data;
    DLLNode node;
} MyData;

DLLHeader list;
dll_init(&list, offsetof(MyData, node));
```

### dll_insert_front
```c
void dll_insert_front(DLLHeader *hdr, void *entry);
```
**Description**: Inserts a new entry at the beginning of the list.

**Parameters**:
- `hdr`: Pointer to the list header
- `entry`: Pointer to the entry to insert (must contain an embedded DLLNode)

**Time Complexity**: O(1)

### dll_insert_end
```c
void dll_insert_end(DLLHeader *hdr, void *entry);
```
**Description**: Inserts a new entry at the end of the list.

**Parameters**:
- `hdr`: Pointer to the list header
- `entry`: Pointer to the entry to insert (must contain an embedded DLLNode)

**Time Complexity**: O(1)

### dll_remove
```c
void dll_remove(DLLHeader *hdr, void *entry);
```
**Description**: Removes a specific entry from the list.

**Parameters**:
- `hdr`: Pointer to the list header
- `entry`: Pointer to the entry to remove

**Time Complexity**: O(1) - direct removal without traversal

**Note**: Unlike SLL, DLL removal is O(1) because the node contains both prev and next pointers.

### dll_pop_front
```c
void* dll_pop_front(DLLHeader *hdr);
```
**Description**: Removes and returns the first entry in the list.

**Parameters**:
- `hdr`: Pointer to the list header

**Returns**: Pointer to the removed entry, or NULL if the list is empty

**Time Complexity**: O(1)

### dll_pop_end
```c
void* dll_pop_end(DLLHeader *hdr);
```
**Description**: Removes and returns the last entry in the list.

**Parameters**:
- `hdr`: Pointer to the list header

**Returns**: Pointer to the removed entry, or NULL if the list is empty

**Time Complexity**: O(1)

**Note**: This operation is not available in SLL but is O(1) in DLL.

### dll_find
```c
void* dll_find(DLLHeader *hdr, bool (*cmp)(void *entry, void *arg), void *arg);
```
**Description**: Searches for an entry in the list using a custom comparison function.

**Parameters**:
- `hdr`: Pointer to the list header
- `cmp`: Comparison function that returns true when the desired entry is found
- `arg`: User-defined argument passed to the comparison function

**Returns**: Pointer to the found entry, or NULL if not found

**Time Complexity**: O(n)

**Example**:
```c
bool find_by_id(void *entry, void *arg) {
    MyData *data = entry;
    int *target_id = arg;
    return data->id == *target_id;
}

int id_to_find = 42;
MyData *found = dll_find(&list, find_by_id, &id_to_find);
```

## Macros

### DLL_COUNT
```c
#define DLL_COUNT(hdr) ((hdr)->u4_cnt)
```
**Description**: Returns the number of entries in the list.

**Parameters**:
- `hdr`: Pointer to the list header

**Returns**: Number of entries (u4)

### DLL_FIRST
```c
#define DLL_FIRST(hdr) ((hdr)->ps_head)
```
**Description**: Returns the first node in the list.

**Parameters**:
- `hdr`: Pointer to the list header

**Returns**: Pointer to the first DLLNode, or NULL if empty

### DLL_LAST
```c
#define DLL_LAST(hdr) ((hdr)->ps_tail)
```
**Description**: Returns the last node in the list.

**Parameters**:
- `hdr`: Pointer to the list header

**Returns**: Pointer to the last DLLNode, or NULL if empty

### DLL_FOREACH
```c
#define DLL_FOREACH(hdr, iter) \
    for ((iter) = (hdr)->ps_head; (iter) != NULL; (iter) = (iter)->ps_next)
```
**Description**: Iterates through all nodes in the list from head to tail.

**Parameters**:
- `hdr`: Pointer to the list header
- `iter`: Iterator variable of type DLLNode*

**Example**:
```c
DLLNode *node;
DLL_FOREACH(&list, node) {
    MyData *data = DLL_ENTRY(node, MyData, node);
    printf("Data: %d\n", data->value);
}
```

### DLL_FOREACH_REVERSE
```c
#define DLL_FOREACH_REVERSE(hdr, iter) \
    for ((iter) = (hdr)->ps_tail; (iter) != NULL; (iter) = (iter)->ps_prev)
```
**Description**: Iterates through all nodes in the list from tail to head.

**Parameters**:
- `hdr`: Pointer to the list header
- `iter`: Iterator variable of type DLLNode*

**Example**:
```c
DLLNode *node;
DLL_FOREACH_REVERSE(&list, node) {
    MyData *data = DLL_ENTRY(node, MyData, node);
    printf("Data: %d\n", data->value);
}
```

**Note**: This reverse iteration capability is unique to DLL and not available in SLL.

### DLL_ENTRY
```c
#define DLL_ENTRY(node, type, member) \
    ((type *)((char *)(node) - offsetof(type, member)))
```
**Description**: Converts a DLLNode pointer to its containing structure.

**Parameters**:
- `node`: Pointer to the DLLNode
- `type`: Type of the containing structure
- `member`: Name of the DLLNode member within the structure

**Returns**: Pointer to the containing structure

**Example**:
```c
DLLNode *node = DLL_FIRST(&list);
MyData *data = DLL_ENTRY(node, MyData, node);
```

## Usage Example

```c
#include "utldll.h"
#include <stdio.h>

typedef struct {
    int id;
    char name[32];
    DLLNode node;
} Person;

int main() {
    DLLHeader people_list;
    
    // Initialize the list
    dll_init(&people_list, offsetof(Person, node));
    
    // Create and insert people
    Person p1 = {1, "Alice", {0}};
    Person p2 = {2, "Bob", {0}};
    Person p3 = {3, "Charlie", {0}};
    
    dll_insert_end(&people_list, &p1);
    dll_insert_end(&people_list, &p2);
    dll_insert_front(&people_list, &p3);
    
    // Print list count
    printf("List contains %u people\n", DLL_COUNT(&people_list));
    
    // Forward iteration
    printf("Forward iteration:\n");
    DLLNode *node;
    DLL_FOREACH(&people_list, node) {
        Person *p = DLL_ENTRY(node, Person, node);
        printf("ID: %d, Name: %s\n", p->id, p->name);
    }
    
    // Reverse iteration
    printf("\nReverse iteration:\n");
    DLL_FOREACH_REVERSE(&people_list, node) {
        Person *p = DLL_ENTRY(node, Person, node);
        printf("ID: %d, Name: %s\n", p->id, p->name);
    }
    
    // Remove Bob (O(1) operation)
    dll_remove(&people_list, &p2);
    
    // Pop from both ends
    Person *first = dll_pop_front(&people_list);
    if (first) {
        printf("\nPopped from front: %s\n", first->name);
    }
    
    Person *last = dll_pop_end(&people_list);
    if (last) {
        printf("Popped from end: %s\n", last->name);
    }
    
    return 0;
}
```

## Key Differences from SLL

1. **Bidirectional Traversal**: DLL supports both forward and reverse iteration through `DLL_FOREACH_REVERSE`
2. **O(1) Removal**: The `dll_remove` function is O(1) compared to O(n) in SLL
3. **Pop from End**: DLL provides `dll_pop_end` which is O(1), while SLL only supports popping from the front
4. **Memory Overhead**: Each node requires an additional pointer (ps_prev), increasing memory usage
5. **Complexity**: Slightly more complex implementation due to maintaining bidirectional links

## Notes
- The DLL implementation uses an intrusive design pattern, meaning the list node must be embedded within your data structure
- All operations maintain head and tail pointers with bidirectional links
- The list does not manage memory allocation/deallocation - the caller is responsible for managing the lifetime of list entries
- Thread safety is not provided - external synchronization is required for concurrent access
- Choose DLL over SLL when you need bidirectional traversal, O(1) removal, or frequent operations at both ends of the list