#include <stdio.h>
#include <stdlib.h>
#include "utlrbtree.h"

#define NODE(entry, tree) ((RBTNode *)((char *)(entry) + (tree)->u4_offset))

// --- Internal Helpers ---

static void rotate_left(RBTree *tree, RBTNode *x) {
    RBTNode *y = x->ps_right;
    x->ps_right = y->ps_left;
    if (y->ps_left) y->ps_left->ps_parent = x;
    y->ps_parent = x->ps_parent;

    if (!x->ps_parent)
        tree->ps_root = y;
    else if (x == x->ps_parent->ps_left)
        x->ps_parent->ps_left = y;
    else
        x->ps_parent->ps_right = y;

    y->ps_left = x;
    x->ps_parent = y;
}

static void rotate_right(RBTree *tree, RBTNode *x) {
    RBTNode *y = x->ps_left;
    x->ps_left = y->ps_right;
    if (y->ps_right) y->ps_right->ps_parent = x;
    y->ps_parent = x->ps_parent;

    if (!x->ps_parent)
        tree->ps_root = y;
    else if (x == x->ps_parent->ps_right)
        x->ps_parent->ps_right = y;
    else
        x->ps_parent->ps_left = y;

    y->ps_right = x;
    x->ps_parent = y;
}

static void insert_fixup(RBTree *tree, RBTNode *z) {
    while (z->ps_parent && z->ps_parent->e_color == RBT_RED) {
        RBTNode *gp = z->ps_parent->ps_parent;
        if (z->ps_parent == gp->ps_left) {
            RBTNode *y = gp->ps_right;
            if (y && y->e_color == RBT_RED) {
                z->ps_parent->e_color = RBT_BLACK;
                y->e_color = RBT_BLACK;
                gp->e_color = RBT_RED;
                z = gp;
            } else {
                if (z == z->ps_parent->ps_right) {
                    z = z->ps_parent;
                    rotate_left(tree, z);
                }
                z->ps_parent->e_color = RBT_BLACK;
                gp->e_color = RBT_RED;
                rotate_right(tree, gp);
            }
        } else {
            RBTNode *y = gp->ps_left;
            if (y && y->e_color == RBT_RED) {
                z->ps_parent->e_color = RBT_BLACK;
                y->e_color = RBT_BLACK;
                gp->e_color = RBT_RED;
                z = gp;
            } else {
                if (z == z->ps_parent->ps_left) {
                    z = z->ps_parent;
                    rotate_right(tree, z);
                }
                z->ps_parent->e_color = RBT_BLACK;
                gp->e_color = RBT_RED;
                rotate_left(tree, gp);
            }
        }
    }
    tree->ps_root->e_color = RBT_BLACK;
}

// --- Public APIs ---

void rbtree_init(RBTree *ps_tree, size_t offset, int (*cmp)(const void *, const void *)) {
    ps_tree->ps_root = NULL;
    ps_tree->u4_offset = (u4)offset;
    ps_tree->pf_compare = cmp;
}

void rbtree_insert(RBTree *tree, void *entry) {
    RBTNode *z = NODE(entry, tree);
    z->ps_left = z->ps_right = z->ps_parent = NULL;
    z->e_color = RBT_RED;

    RBTNode **p = &tree->ps_root, *parent = NULL;
    while (*p) {
        parent = *p;
        void *cur = (char *)(*p) - tree->u4_offset;
        if (tree->pf_compare(entry, cur) < 0)
            p = &((*p)->ps_left);
        else
            p = &((*p)->ps_right);
    }

    z->ps_parent = parent;
    if (!parent)
        tree->ps_root = z;
    else if (tree->pf_compare(entry, (char *)parent - tree->u4_offset) < 0)
        parent->ps_left = z;
    else
        parent->ps_right = z;

    insert_fixup(tree, z);
}

void* rbtree_find(RBTree *tree, void *key) {
    RBTNode *n = tree->ps_root;
    while (n) {
        void *entry = (char *)n - tree->u4_offset;
        int cmp = tree->pf_compare(key, entry);
        if (cmp == 0) return entry;
        n = (cmp < 0) ? n->ps_left : n->ps_right;
    }
    return NULL;
}

void* rbtree_min(RBTree *tree) {
    RBTNode *n = tree->ps_root;
    if (!n) return NULL;
    while (n->ps_left) n = n->ps_left;
    return (char *)n - tree->u4_offset;
}

void* rbtree_max(RBTree *tree) {
    RBTNode *n = tree->ps_root;
    if (!n) return NULL;
    while (n->ps_right) n = n->ps_right;
    return (char *)n - tree->u4_offset;
}

void* rbtree_next(RBTree *tree, void *entry) {
    RBTNode *x = NODE(entry, tree);
    if (x->ps_right) {
        x = x->ps_right;
        while (x->ps_left) x = x->ps_left;
        return (char *)x - tree->u4_offset;
    }
    RBTNode *p = x->ps_parent;
    while (p && x == p->ps_right) {
        x = p;
        p = p->ps_parent;
    }
    return p ? (char *)p - tree->u4_offset : NULL;
}

void* rbtree_prev(RBTree *tree, void *entry) {
    RBTNode *x = NODE(entry, tree);
    if (x->ps_left) {
        x = x->ps_left;
        while (x->ps_right) x = x->ps_right;
        return (char *)x - tree->u4_offset;
    }
    RBTNode *p = x->ps_parent;
    while (p && x == p->ps_left) {
        x = p;
        p = p->ps_parent;
    }
    return p ? (char *)p - tree->u4_offset : NULL;
}

void* rbtree_lower_bound(RBTree *tree, void *key) {
    RBTNode *n = tree->ps_root, *res = NULL;
    while (n) {
        void *entry = (char *)n - tree->u4_offset;
        if (tree->pf_compare(entry, key) < 0)
            n = n->ps_right;
        else {
            res = n;
            n = n->ps_left;
        }
    }
    return res ? (char *)res - tree->u4_offset : NULL;
}

void* rbtree_upper_bound(RBTree *tree, void *key) {
    RBTNode *n = tree->ps_root, *res = NULL;
    while (n) {
        void *entry = (char *)n - tree->u4_offset;
        if (tree->pf_compare(entry, key) <= 0)
            n = n->ps_right;
        else {
            res = n;
            n = n->ps_left;
        }
    }
    return res ? (char *)res - tree->u4_offset : NULL;
}

void* rbtree_find_or_insert(RBTree *tree, void *entry, bool *inserted) {
    void *found = rbtree_find(tree, entry);
    if (found) {
        if (inserted) *inserted = false;
        return found;
    }
    rbtree_insert(tree, entry);
    if (inserted) *inserted = true;
    return entry;
}

// --- Deletion ---

static void transplant(RBTree *tree, RBTNode *u, RBTNode *v) {
    if (!u->ps_parent)
        tree->ps_root = v;
    else if (u == u->ps_parent->ps_left)
        u->ps_parent->ps_left = v;
    else
        u->ps_parent->ps_right = v;
    if (v) v->ps_parent = u->ps_parent;
}

static void delete_fixup(RBTree *tree, RBTNode *x, RBTNode *x_parent) {
    while (x != tree->ps_root && (!x || x->e_color == RBT_BLACK)) {
        if (x == x_parent->ps_left) {
            RBTNode *w = x_parent->ps_right;
            if (w && w->e_color == RBT_RED) {
                w->e_color = RBT_BLACK;
                x_parent->e_color = RBT_RED;
                rotate_left(tree, x_parent);
                w = x_parent->ps_right;
            }
            if (!w || ((w->ps_left == NULL || w->ps_left->e_color == RBT_BLACK) && (w->ps_right == NULL || w->ps_right->e_color == RBT_BLACK))) {
                if (w) w->e_color = RBT_RED;
                x = x_parent;
                x_parent = x->ps_parent;
            } else {
                if (!w || !w->ps_right || w->ps_right->e_color == RBT_BLACK) {
                    if (w->ps_left) w->ps_left->e_color = RBT_BLACK;
                    w->e_color = RBT_RED;
                    rotate_right(tree, w);
                    w = x_parent->ps_right;
                }
                if (w) w->e_color = x_parent->e_color;
                x_parent->e_color = RBT_BLACK;
                if (w && w->ps_right) w->ps_right->e_color = RBT_BLACK;
                rotate_left(tree, x_parent);
                x = tree->ps_root;
            }
        } else {
            RBTNode *w = x_parent->ps_left;
            if (w && w->e_color == RBT_RED) {
                w->e_color = RBT_BLACK;
                x_parent->e_color = RBT_RED;
                rotate_right(tree, x_parent);
                w = x_parent->ps_left;
            }
            if (!w || ((w->ps_right == NULL || w->ps_right->e_color == RBT_BLACK) && (w->ps_left == NULL || w->ps_left->e_color == RBT_BLACK))) {
                if (w) w->e_color = RBT_RED;
                x = x_parent;
                x_parent = x->ps_parent;
            } else {
                if (!w || !w->ps_left || w->ps_left->e_color == RBT_BLACK) {
                    if (w->ps_right) w->ps_right->e_color = RBT_BLACK;
                    w->e_color = RBT_RED;
                    rotate_left(tree, w);
                    w = x_parent->ps_left;
                }
                if (w) w->e_color = x_parent->e_color;
                x_parent->e_color = RBT_BLACK;
                if (w && w->ps_left) w->ps_left->e_color = RBT_BLACK;
                rotate_right(tree, x_parent);
                x = tree->ps_root;
            }
        }
    }
    if (x) x->e_color = RBT_BLACK;
}

void rbtree_remove(RBTree *tree, void *entry) {
    RBTNode *z = NODE(entry, tree), *y = z, *x = NULL, *x_parent = NULL;
    RBTColor y_original_color = y->e_color;

    if (!z->ps_left) {
        x = z->ps_right;
        x_parent = z->ps_parent;
        transplant(tree, z, z->ps_right);
    } else if (!z->ps_right) {
        x = z->ps_left;
        x_parent = z->ps_parent;
        transplant(tree, z, z->ps_left);
    } else {
        y = z->ps_right;
        while (y->ps_left) y = y->ps_left;
        y_original_color = y->e_color;
        x = y->ps_right;
        if (y->ps_parent == z) {
            if (x) x->ps_parent = y;
            x_parent = y;
        } else {
            transplant(tree, y, y->ps_right);
            y->ps_right = z->ps_right;
            if (y->ps_right) y->ps_right->ps_parent = y;
            x_parent = y->ps_parent;
        }
        transplant(tree, z, y);
        y->ps_left = z->ps_left;
        if (y->ps_left) y->ps_left->ps_parent = y;
        y->e_color = z->e_color;
    }

    if (y_original_color == RBT_BLACK)
        delete_fixup(tree, x, x_parent);
}

// --- Debug Utilities ---

static void print_indent(int level) {
    for (int i = 0; i < level; i++) printf("  ");
}

static void print_node(RBTNode *node, void (*print_entry)(void *, int), size_t offset, int level) {
    if (!node) return;
    print_node(node->ps_right, print_entry, offset, level + 1);
    print_indent(level);
    void *entry = (char *)node - offset;
    print_entry(entry, level);
    print_node(node->ps_left, print_entry, offset, level + 1);
}

void rbtree_print(RBTree *tree, void (*print_entry)(void *entry, int depth)) {
    if (tree->ps_root == NULL) {
        printf("[empty tree]\n");
        return;
    }
    print_node(tree->ps_root, print_entry, tree->u4_offset, 0);
}

static bool verify_node(RBTNode *node, int *black_height, size_t offset) {
    if (!node) {
        *black_height = 1;
        return true;
    }

    RBTNode *l = node->ps_left;
    RBTNode *r = node->ps_right;

    if (node->e_color == RBT_RED) {
        if ((l && l->e_color == RBT_RED) || (r && r->e_color == RBT_RED))
            return false;
    }

    int lh = 0, rh = 0;
    if (!verify_node(l, &lh, offset) || !verify_node(r, &rh, offset))
        return false;

    if (lh != rh)
        return false;

    *black_height = lh + (node->e_color == RBT_BLACK ? 1 : 0);
    return true;
}

bool rbtree_verify(RBTree *tree) {
    if (!tree->ps_root) return true;
    if (tree->ps_root->e_color != RBT_BLACK) return false;

    int bh = 0;
    return verify_node(tree->ps_root, &bh, tree->u4_offset);
}

// --- Statistics Helpers ---

static size_t node_count_recursive(RBTNode *node) {
    if (!node) return 0;
    return 1 + node_count_recursive(node->ps_left) + node_count_recursive(node->ps_right);
}

static size_t height_recursive(RBTNode *node) {
    if (!node) return 0;
    size_t lh = height_recursive(node->ps_left);
    size_t rh = height_recursive(node->ps_right);
    return (lh > rh ? lh : rh) + 1;
}

size_t rbtree_node_count(RBTree *tree) {
    return node_count_recursive(tree->ps_root);
}

size_t rbtree_height(RBTree *tree) {
    return height_recursive(tree->ps_root);
}

void rbtree_print_stats(RBTree *tree) {
    size_t nodes = rbtree_node_count(tree);
    size_t height = rbtree_height(tree);
    printf("RBTree Stats: nodes=%zu height=%zu\n", nodes, height);
}

