#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#include "utldll.h"

typedef struct MyItem {
    int id;
    char name[32];
    DLLNode node;
} MyItem;

bool match_id(void *entry, void *arg) {
    MyItem *item = (MyItem *)entry;
    int *id = (int *)arg;
    return item->id == *id;
}

static int s4_tests_passed = 0;
static int s4_tests_failed = 0;

#define START_TEST(id, desc) \
    printf("\nTest Case %s - %s\n", id, desc);

#define END_TEST(cond)                                       \
    do {                                                    \
        if (cond) {                                         \
            printf("Result: PASS\n");                      \
            s4_tests_passed++;                               \
        } else {                                            \
            printf("Result: FAIL\n");                      \
            s4_tests_failed++;                               \
        }                                                   \
    } while (0)

int main() {
    DLLHeader list;
    MyItem item1 = { .id = 101, .name = "Alpha" };
    MyItem item2 = { .id = 102, .name = "Beta" };
    MyItem item3 = { .id = 103, .name = "Gamma" };

    START_TEST("TC01", "Initialize list using dll_init");
    dll_init(&list, offsetof(MyItem, node));
    END_TEST(DLL_COUNT(&list) == 0 && DLL_FIRST(&list) == NULL &&
             DLL_LAST(&list) == NULL);

    START_TEST("TC02", "Insert first item using dll_insert_end");
    dll_insert_end(&list, &item1);
    END_TEST(DLL_COUNT(&list) == 1 &&
             DLL_FIRST(&list) == &item1.node &&
             DLL_LAST(&list) == &item1.node);

    START_TEST("TC03", "Insert second item using dll_insert_end");
    dll_insert_end(&list, &item2);
    END_TEST(DLL_COUNT(&list) == 2 &&
             DLL_FIRST(&list) == &item1.node &&
             DLL_LAST(&list) == &item2.node);

    START_TEST("TC04", "Insert item at front using dll_insert_front");
    dll_insert_front(&list, &item3); /* Gamma -> Alpha -> Beta */
    END_TEST(DLL_COUNT(&list) == 3 &&
             DLL_FIRST(&list) == &item3.node &&
             DLL_LAST(&list) == &item2.node);

    START_TEST("TC05", "Iterate forward using DLL_FOREACH to verify order");
    int fwd[3];
    int idx = 0;
    DLLNode *iter;
    DLL_FOREACH(&list, iter) {
        MyItem *entry = DLL_ENTRY(iter, MyItem, node);
        fwd[idx++] = entry->id;
    }
    END_TEST(idx == 3 && fwd[0] == 103 && fwd[1] == 101 && fwd[2] == 102);

    START_TEST("TC06", "Iterate reverse using DLL_FOREACH_REVERSE");
    int rev[3];
    idx = 0;
    DLL_FOREACH_REVERSE(&list, iter) {
        MyItem *entry = DLL_ENTRY(iter, MyItem, node);
        rev[idx++] = entry->id;
    }
    END_TEST(idx == 3 && rev[0] == 102 && rev[1] == 101 && rev[2] == 103);

    START_TEST("TC07", "Find item2 using dll_find");
    int search_id = 102;
    MyItem *found = dll_find(&list, match_id, &search_id);
    END_TEST(found == &item2);

    START_TEST("TC08", "Remove item2 using dll_remove");
    dll_remove(&list, &item2);
    search_id = 102;
    found = dll_find(&list, match_id, &search_id);
    END_TEST(DLL_COUNT(&list) == 2 &&
             found == NULL &&
             DLL_FIRST(&list) == &item3.node &&
             DLL_LAST(&list) == &item1.node);

    START_TEST("TC09", "Pop end item using dll_pop_end");
    MyItem *popped = (MyItem *)dll_pop_end(&list);
    END_TEST(popped == &item1 &&
             DLL_COUNT(&list) == 1 &&
             DLL_FIRST(&list) == &item3.node &&
             DLL_LAST(&list) == &item3.node);

    START_TEST("TC10", "Pop front item using dll_pop_front");
    popped = (MyItem *)dll_pop_front(&list);
    END_TEST(popped == &item3 &&
             DLL_COUNT(&list) == 0 &&
             DLL_FIRST(&list) == NULL &&
             DLL_LAST(&list) == NULL);

    START_TEST("TC11", "Verify remaining count");
    END_TEST(DLL_COUNT(&list) == 0);

    // --- Performance Test ---
    typedef struct {
        char name[16];
        DLLNode node;
    } EthIf;

    START_TEST("TC12", "Insert and remove 1000 ethernet interfaces");
    DLLHeader perf_hdr;
    dll_init(&perf_hdr, offsetof(EthIf, node));
    EthIf ifs[1000];
    clock_t start = clock();
    for (int i = 0; i < 1000; i++) {
        snprintf(ifs[i].name, sizeof(ifs[i].name), "ETH%06d", i + 1);
        dll_insert_end(&perf_hdr, &ifs[i]);
    }
    clock_t mid = clock();
    for (int i = 999; i >= 0; i--) {
        dll_remove(&perf_hdr, &ifs[i]);
    }
    clock_t end = clock();
    double insert_ms = (double)(mid - start) * 1000.0 / CLOCKS_PER_SEC;
    double delete_ms = (double)(end - mid) * 1000.0 / CLOCKS_PER_SEC;
    printf("Inserted 1000 and removed in %.2f/%.2f ms\n", insert_ms, delete_ms);
    END_TEST(DLL_COUNT(&perf_hdr) == 0);

    printf("\nConsolidated Test Report:\n");
    printf("Total: %d, Passed: %d, Failed: %d\n",
           s4_tests_passed + s4_tests_failed,
           s4_tests_passed, s4_tests_failed);

    return s4_tests_failed == 0 ? 0 : 1;
}

