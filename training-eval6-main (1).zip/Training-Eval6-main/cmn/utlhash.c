#include <stdlib.h>
#include <stdio.h>
#include "utlhash.h"

bool hash_table_init(HashTable *ht, size_t bucket_count, size_t offset,
                     size_t (*hash_func)(void *, size_t),
                     bool (*key_eq_func)(void *, void *)) {
    ht->buckets = (DLLHeader *)calloc(bucket_count, sizeof(DLLHeader));
    if (!ht->buckets)
        return false;

    ht->bucket_count = bucket_count;
    ht->offset = offset;
    ht->hash_func = hash_func;
    ht->key_eq_func = key_eq_func;

    for (size_t i = 0; i < bucket_count; i++)
        dll_init(&ht->buckets[i], offset);

    return true;
}

void hash_table_insert(HashTable *ht, void *entry) {
    size_t index = ht->hash_func(entry, ht->bucket_count);
    dll_insert_end(&ht->buckets[index], entry);
}

void* hash_table_find(HashTable *ht, void *key) {
    size_t i = ht->hash_func(key, ht->bucket_count);
    DLLNode *node;
    DLL_FOREACH(&ht->buckets[i], node) {
        void *entry = (char *)node - ht->offset;
        if (ht->key_eq_func(entry, key))
            return entry;
    }
    return NULL;
}

void hash_table_remove(HashTable *ht, void *entry) {
    size_t index = ht->hash_func(entry, ht->bucket_count);
    dll_remove(&ht->buckets[index], entry);
}

void hash_table_destroy(HashTable *ht) {
    free(ht->buckets);
    ht->buckets = NULL;
    ht->bucket_count = 0;
}

size_t hash_table_entry_count(HashTable *ht) {
    size_t total = 0;
    for (size_t i = 0; i < ht->bucket_count; i++)
        total += DLL_COUNT(&ht->buckets[i]);
    return total;
}

void hash_table_print_stats(HashTable *ht) {
    size_t used = 0, min = (size_t)-1, max = 0, total = 0, collisions = 0;
    for (size_t i = 0; i < ht->bucket_count; i++) {
        size_t cnt = DLL_COUNT(&ht->buckets[i]);
        if (cnt) {
            used++;
            if (cnt > 1)
                collisions += cnt - 1;
        }
        if (cnt < min)
            min = cnt;
        if (cnt > max)
            max = cnt;
        total += cnt;
    }

    double avg = (double)total / ht->bucket_count;
    printf("HashTable Stats: buckets=%zu used=%zu collisions=%zu avg=%.2f min=%zu max=%zu\n",
           ht->bucket_count, used, collisions, avg, min, max);
}

