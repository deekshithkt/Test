#include "utldll.h"

void dll_init(DLLHeader *hdr, size_t offset) {
    hdr->ps_head = hdr->ps_tail = NULL;
    hdr->u4_cnt = 0;
    hdr->u4_offset = (u4)offset;
}

void dll_insert_front(DLLHeader *hdr, void *entry) {
    DLLNode *node = (DLLNode *)((char *)entry + hdr->u4_offset);
    node->ps_prev = NULL;
    node->ps_next = hdr->ps_head;

    if (hdr->ps_head)
        hdr->ps_head->ps_prev = node;
    else
        hdr->ps_tail = node;

    hdr->ps_head = node;
    hdr->u4_cnt++;
}

void dll_insert_end(DLLHeader *hdr, void *entry) {
    DLLNode *node = (DLLNode *)((char *)entry + hdr->u4_offset);
    node->ps_next = NULL;
    node->ps_prev = hdr->ps_tail;

    if (hdr->ps_tail)
        hdr->ps_tail->ps_next = node;
    else
        hdr->ps_head = node;

    hdr->ps_tail = node;
    hdr->u4_cnt++;
}

void dll_remove(DLLHeader *hdr, void *entry) {
    DLLNode *node = (DLLNode *)((char *)entry + hdr->u4_offset);

    if (node->ps_prev)
        node->ps_prev->ps_next = node->ps_next;
    else
        hdr->ps_head = node->ps_next;

    if (node->ps_next)
        node->ps_next->ps_prev = node->ps_prev;
    else
        hdr->ps_tail = node->ps_prev;

    hdr->u4_cnt--;
}

void* dll_pop_front(DLLHeader *hdr) {
    if (!hdr->ps_head)
        return NULL;

    DLLNode *node = hdr->ps_head;
    hdr->ps_head = node->ps_next;

    if (hdr->ps_head)
        hdr->ps_head->ps_prev = NULL;
    else
        hdr->ps_tail = NULL;

    hdr->u4_cnt--;
    return (void *)((char *)node - hdr->u4_offset);
}

void* dll_pop_end(DLLHeader *hdr) {
    if (!hdr->ps_tail)
        return NULL;

    DLLNode *node = hdr->ps_tail;
    hdr->ps_tail = node->ps_prev;

    if (hdr->ps_tail)
        hdr->ps_tail->ps_next = NULL;
    else
        hdr->ps_head = NULL;

    hdr->u4_cnt--;
    return (void *)((char *)node - hdr->u4_offset);
}

void* dll_find(DLLHeader *hdr, bool (*cmp)(void *entry, void *arg), void *arg) {
    DLLNode *node = hdr->ps_head;
    while (node) {
        void *entry = (char *)node - hdr->u4_offset;
        if (cmp(entry, arg))
            return entry;
        node = node->ps_next;
    }
    return NULL;
}

