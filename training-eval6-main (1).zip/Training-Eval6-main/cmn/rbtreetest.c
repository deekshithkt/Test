#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include "utlrbtree.h"

typedef struct {
    s4      s4_id;
    char    name[32];
    RBTNode node;
} User;

static int s4_tests_passed = 0;
static int s4_tests_failed = 0;

#define START_TEST(id, desc) \
    printf("\nTest Case %s - %s\n", id, desc);

#define END_TEST(cond)                                           \
    do {                                                         \
        if (cond) {                                              \
            printf("Result: PASS\n");                           \
            s4_tests_passed++;                                   \
        } else {                                                 \
            printf("Result: FAIL\n");                           \
            s4_tests_failed++;                                   \
        }                                                        \
    } while (0)

int compare_users(const void *a, const void *b) {
    return ((User *)a)->s4_id - ((User *)b)->s4_id;
}

void print_user(void *entry, int depth) {
    User *u = (User *)entry;
    RBTNode *n = &u->node;
    printf("%*s[%d] %s (%s)\n", depth * 2, "", u->s4_id, u->name,
           n->e_color == RBT_RED ? "R" : "B");
}

typedef struct {
    char    name[16];
    RBTNode node;
} EthIf;

int eth_compare(const void *a, const void *b) {
    int na = atoi(((const EthIf *)a)->name + 3);
    int nb = atoi(((const EthIf *)b)->name + 3);
    return na - nb;
}

void test_rbtree_debug(RBTree *tree) {
    printf("\n[Tree structure]\n");
    rbtree_print(tree, print_user);

    printf("\n[In-order traversal]\n");
    RBTNode *iter;
    RBTREE_FOREACH(tree, iter) {
        User *u = RBT_ENTRY(iter, User, node);
        printf("  %d: %s\n", u->s4_id, u->name);
    }

    printf("\n[Tree verification] %s\n", rbtree_verify(tree) ? "PASSED" : "FAILED");
}

int main() {
    RBTree tree;

    START_TEST("TC01", "Initialize tree using rbtree_init");
    rbtree_init(&tree, offsetof(User, node), compare_users);
    END_TEST(tree.ps_root == NULL);

    User users[] = {
        { .s4_id = 101, .name = "Alice" },
        { .s4_id =  50, .name = "Bob" },
        { .s4_id = 150, .name = "Charlie" },
        { .s4_id =  25, .name = "Dave" },
        { .s4_id =  75, .name = "Eve" },
        { .s4_id = 120, .name = "Frank" },
        { .s4_id = 180, .name = "Grace" },
        { .s4_id =  60, .name = "Hank" },
        { .s4_id = 130, .name = "Ivy" },
    };

    START_TEST("TC02", "Insert users using rbtree_insert");
    for (int i = 0; i < (int)(sizeof(users) / sizeof(users[0])); i++) {
        rbtree_insert(&tree, &users[i]);
    }
    User *min = rbtree_min(&tree);
    User *max = rbtree_max(&tree);
    END_TEST(rbtree_verify(&tree) && min == &users[3] && max == &users[6]);

    START_TEST("TC03", "Find existing user using rbtree_find");
    User key = { .s4_id = 75 };
    User *found = rbtree_find(&tree, &key);
    END_TEST(found == &users[4]);

    START_TEST("TC04", "Find missing user using rbtree_find");
    key.s4_id = 999;
    found = rbtree_find(&tree, &key);
    END_TEST(found == NULL);

    START_TEST("TC05", "Locate lower bound using rbtree_lower_bound");
    key.s4_id = 76;
    found = rbtree_lower_bound(&tree, &key);
    END_TEST(found == &users[0]);

    START_TEST("TC06", "Locate upper bound using rbtree_upper_bound");
    key.s4_id = 75;
    found = rbtree_upper_bound(&tree, &key);
    END_TEST(found == &users[0]);

    START_TEST("TC07", "Find or insert existing key using rbtree_find_or_insert");
    bool inserted = false;
    found = rbtree_find_or_insert(&tree, &users[2], &inserted);
    END_TEST(found == &users[2] && inserted == false);

    START_TEST("TC08", "Navigate using rbtree_next and rbtree_prev");
    User *next = rbtree_next(&tree, &users[4]);
    User *prev = rbtree_prev(&tree, &users[0]);
    END_TEST(next == &users[0] && prev == &users[4]);

    START_TEST("TC09", "Remove node using rbtree_remove");
    rbtree_remove(&tree, &users[5]);
    key.s4_id = 120;
    found = rbtree_find(&tree, &key);
    END_TEST(found == NULL && rbtree_verify(&tree));

    START_TEST("TC10", "Remove root node and verify");
    rbtree_remove(&tree, &users[0]);
    key.s4_id = 101;
    found = rbtree_find(&tree, &key);
    END_TEST(found == NULL && rbtree_verify(&tree));

    // --- Performance Tests ---

    START_TEST("TC11", "Insert 1000 ethernet interfaces");
    RBTree perf_tree;
    rbtree_init(&perf_tree, offsetof(EthIf, node), eth_compare);
    EthIf ifs[1000];
    clock_t start = clock();
    for (int i = 0; i < 1000; i++) {
        snprintf(ifs[i].name, sizeof(ifs[i].name), "ETH%06d", i + 1);
        rbtree_insert(&perf_tree, &ifs[i]);
    }
    clock_t end = clock();
    double insert_ms = (double)(end - start) * 1000.0 / CLOCKS_PER_SEC;
    printf("Inserted 1000 entries in %.2f ms\n", insert_ms);
    END_TEST(rbtree_node_count(&perf_tree) == 1000 && rbtree_verify(&perf_tree));

    START_TEST("TC12", "Lookup 1000 ethernet interfaces");
    bool all_found = true;
    start = clock();
    for (int i = 0; i < 1000; i++) {
        EthIf key;
        snprintf(key.name, sizeof(key.name), "ETH%06d", i + 1);
        if (!rbtree_find(&perf_tree, &key)) {
            all_found = false;
            break;
        }
    }
    end = clock();
    double lookup_ms = (double)(end - start) * 1000.0 / CLOCKS_PER_SEC;
    printf("Lookup of 1000 entries took %.2f ms\n", lookup_ms);
    END_TEST(all_found);

    START_TEST("TC13", "Delete 1000 ethernet interfaces in reverse order");
    start = clock();
    for (int i = 999; i >= 0; i--) {
        rbtree_remove(&perf_tree, &ifs[i]);
    }
    end = clock();
    double delete_ms = (double)(end - start) * 1000.0 / CLOCKS_PER_SEC;
    printf("Deletion of 1000 entries took %.2f ms\n", delete_ms);
    END_TEST(rbtree_node_count(&perf_tree) == 0 && rbtree_verify(&perf_tree));

    rbtree_print_stats(&perf_tree);

    printf("\nConsolidated Test Report:\n");
    printf("Total: %d, Passed: %d, Failed: %d\n",
           s4_tests_passed + s4_tests_failed,
           s4_tests_passed, s4_tests_failed);

    return s4_tests_failed == 0 ? 0 : 1;
}

