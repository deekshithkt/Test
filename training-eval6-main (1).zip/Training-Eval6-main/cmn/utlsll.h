#ifndef __UTLSLL_H__
#define __UTLSLL_H__

#include <stddef.h>
#include <stdbool.h>
#include "ostypes.h"

typedef struct SLLNode {
    struct SLLNode *ps_next;
} SLLNode;

typedef struct {
    SLLNode *ps_head;
    SLLNode *ps_tail;
    u4       u4_cnt;
    u4       u4_offset;
} SLLHeader;

#ifdef __cplusplus
extern "C" {
#endif

void sll_init(SLLHeader *hdr, size_t offset);
void sll_insert_front(SLLHeader *hdr, void *entry);
void sll_insert_end(SLLHeader *hdr, void *entry);
void sll_remove(SLLHeader *hdr, void *entry);
void* sll_pop_front(SLLHeader *hdr);
void* sll_find(SLLHeader *hdr, bool (*cmp)(void *entry, void *arg), void *arg);

#define SLL_COUNT(hdr)    ((hdr)->u4_cnt)
#define SLL_FIRST(hdr)    ((hdr)->ps_head)
#define SLL_LAST(hdr)     ((hdr)->ps_tail)

#define SLL_FOREACH(hdr, iter)                                 \
    for ((iter) = (hdr)->ps_head; (iter) != NULL; (iter) = (iter)->ps_next)

#define SLL_ENTRY(node, type, member)                          \
    ((type *)((char *)(node) - offsetof(type, member)))

#ifdef __cplusplus
}
#endif

#endif // __UTLSLL_H__

