#include "utlsll.h"

void sll_init(SLLHeader *hdr, size_t offset) {
    hdr->ps_head = hdr->ps_tail = NULL;
    hdr->u4_cnt = 0;
    hdr->u4_offset = (u4)offset;
}

void sll_insert_front(SLLHeader *hdr, void *entry) {
    SLLNode *node = (SLLNode *)((char *)entry + hdr->u4_offset);
    node->ps_next = hdr->ps_head;
    hdr->ps_head = node;

    if (hdr->ps_tail == NULL)
        hdr->ps_tail = node;

    hdr->u4_cnt++;
}

void sll_insert_end(SLLHeader *hdr, void *entry) {
    SLLNode *node = (SLLNode *)((char *)entry + hdr->u4_offset);
    node->ps_next = NULL;

    if (hdr->ps_tail)
        hdr->ps_tail->ps_next = node;
    else
        hdr->ps_head = node;

    hdr->ps_tail = node;
    hdr->u4_cnt++;
}

void sll_remove(SLLHeader *hdr, void *entry) {
    SLLNode *target = (SLLNode *)((char *)entry + hdr->u4_offset);
    SLLNode *prev = NULL;
    SLLNode *curr = hdr->ps_head;

    while (curr != NULL) {
        if (curr == target) {
            if (prev)
                prev->ps_next = curr->ps_next;
            else
                hdr->ps_head = curr->ps_next;

            if (hdr->ps_tail == curr)
                hdr->ps_tail = prev;

            hdr->u4_cnt--;
            return;
        }
        prev = curr;
        curr = curr->ps_next;
    }
}

void* sll_pop_front(SLLHeader *hdr) {
    if (!hdr->ps_head) return NULL;

    SLLNode *node = hdr->ps_head;
    hdr->ps_head = node->ps_next;

    if (!hdr->ps_head)
        hdr->ps_tail = NULL;

    hdr->u4_cnt--;

    return (void *)((char *)node - hdr->u4_offset);
}

void* sll_find(SLLHeader *hdr, bool (*cmp)(void *entry, void *arg), void *arg) {
    SLLNode *node = hdr->ps_head;
    while (node) {
        void *entry = (char *)node - hdr->u4_offset;
        if (cmp(entry, arg))
            return entry;
        node = node->ps_next;
    }
    return NULL;
}

