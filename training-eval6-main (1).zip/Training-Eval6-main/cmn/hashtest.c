#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include "utlhash.h"

typedef struct {
    int id;
    char name[32];
    DLLNode node;
} User;

static int s4_tests_passed = 0;
static int s4_tests_failed = 0;

#define START_TEST(id, desc) \
    printf("\nTest Case %s - %s\n", id, desc);

#define END_TEST(cond)                                       \
    do {                                                    \
        if (cond) {                                         \
            printf("Result: PASS\n");                      \
            s4_tests_passed++;                               \
        } else {                                            \
            printf("Result: FAIL\n");                      \
            s4_tests_failed++;                               \
        }                                                   \
    } while (0)

size_t user_hash(void *entry, size_t bucket_count) {
    User *u = (User *)entry;
    return (size_t)(u->id) % bucket_count;
}

bool user_key_eq(void *entry, void *key) {
    User *u = (User *)entry;
    int *id = (int *)key;
    return u->id == *id;
}

typedef struct {
    char    name[16];
    DLLNode node;
} EthIf;

size_t eth_hash(void *entry, size_t bucket_count) {
    EthIf *iface = (EthIf *)entry;
    int num = atoi(iface->name + 3);
    return (size_t)num % bucket_count;
}

bool eth_key_eq(void *entry, void *key) {
    EthIf *iface = (EthIf *)entry;
    char *k = (char *)key;
    return strncmp(iface->name, k, sizeof(iface->name)) == 0;
}

int main() {
    HashTable ht;

    START_TEST("TC01", "Initialize hash table");
    bool init_ok = hash_table_init(&ht, 8, offsetof(User, node),
                                  user_hash, user_key_eq);
    END_TEST(init_ok && HASH_TABLE_BUCKET_COUNT(&ht) == 8);

    User u1 = { .id = 101, .name = "Alice" };
    User u2 = { .id = 202, .name = "Bob" };
    User u3 = { .id = 303, .name = "Charlie" };
    User u4 = { .id = 404, .name = "Dave" };

    START_TEST("TC02", "Insert items and verify find");
    hash_table_insert(&ht, &u1);
    hash_table_insert(&ht, &u2);
    hash_table_insert(&ht, &u3);
    hash_table_insert(&ht, &u4);
    int lookup_id = 202;
    User *found = (User *)hash_table_find(&ht, &lookup_id);
    END_TEST(found == &u2);

    START_TEST("TC03", "Remove item and verify missing");
    hash_table_remove(&ht, &u2);
    found = (User *)hash_table_find(&ht, &lookup_id);
    END_TEST(found == NULL);

    START_TEST("TC04", "Iterate all entries");
    int count = 0;
    DLLNode *iter;
    HASH_TABLE_FOREACH_ALL(&ht, bkt, iter) {
        (void)bkt; /* suppress unused warning */
        count++;
    }
    END_TEST(count == 3);

    hash_table_destroy(&ht);

    // --- Performance Tests ---

    START_TEST("TC05", "Insert 1000 ethernet interfaces");
    HashTable perf_ht;
    bool perf_init = hash_table_init(&perf_ht, 256, offsetof(EthIf, node),
                                    eth_hash, eth_key_eq);
    EthIf ifs[1000];
    clock_t start = clock();
    for (int i = 0; i < 1000; i++) {
        snprintf(ifs[i].name, sizeof(ifs[i].name), "ETH%06d", i + 1);
        hash_table_insert(&perf_ht, &ifs[i]);
    }
    clock_t end = clock();
    double insert_ms = (double)(end - start) * 1000.0 / CLOCKS_PER_SEC;
    printf("Inserted 1000 entries in %.2f ms\n", insert_ms);
    END_TEST(perf_init && hash_table_entry_count(&perf_ht) == 1000);

    START_TEST("TC06", "Lookup 1000 ethernet interfaces");
    bool all_found = true;
    start = clock();
    for (int i = 0; i < 1000; i++) {
        char key[16];
        snprintf(key, sizeof(key), "ETH%06d", i + 1);
        if (!hash_table_find(&perf_ht, key)) {
            all_found = false;
            break;
        }
    }
    end = clock();
    double lookup_ms = (double)(end - start) * 1000.0 / CLOCKS_PER_SEC;
    printf("Lookup of 1000 entries took %.2f ms\n", lookup_ms);
    END_TEST(all_found);

    START_TEST("TC07", "Delete 1000 ethernet interfaces in reverse order");
    start = clock();
    for (int i = 999; i >= 0; i--) {
        hash_table_remove(&perf_ht, &ifs[i]);
    }
    end = clock();
    double delete_ms = (double)(end - start) * 1000.0 / CLOCKS_PER_SEC;
    printf("Deletion of 1000 entries took %.2f ms\n", delete_ms);
    END_TEST(hash_table_entry_count(&perf_ht) == 0);

    hash_table_print_stats(&perf_ht);
    hash_table_destroy(&perf_ht);

    printf("\nConsolidated Test Report:\n");
    printf("Total: %d, Passed: %d, Failed: %d\n",
           s4_tests_passed + s4_tests_failed,
           s4_tests_passed, s4_tests_failed);

    return s4_tests_failed == 0 ? 0 : 1;
}

