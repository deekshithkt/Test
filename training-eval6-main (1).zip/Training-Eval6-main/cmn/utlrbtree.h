// utlrbtree.h
#ifndef __UTLRBTREE_H__
#define __UTLRBTREE_H__

#include <stddef.h>
#include <stdbool.h>
#include "ostypes.h"

typedef enum { RBT_RED, RBT_BLACK } RBTColor;

typedef struct RBTNode {
    struct RBTNode *ps_parent;
    struct RBTNode *ps_left;
    struct RBTNode *ps_right;
    RBTColor        e_color;
} RBTNode;

typedef struct {
    RBTNode *ps_root;
    u4       u4_offset;
    int     (*pf_compare)(const void *a, const void *b);
} RBTree;

#ifdef __cplusplus
extern "C" {
#endif

void rbtree_init(RBTree *tree, size_t offset, int (*cmp)(const void *, const void *));
void rbtree_insert(RBTree *tree, void *entry);
void rbtree_remove(RBTree *tree, void *entry);
void* rbtree_find(RBTree *tree, void *key);
void* rbtree_min(RBTree *tree);
void* rbtree_max(RBTree *tree);
void* rbtree_next(RBTree *tree, void *entry);
void* rbtree_prev(RBTree *tree, void *entry);
void* rbtree_lower_bound(RBTree *tree, void *key);
void* rbtree_upper_bound(RBTree *tree, void *key);
void* rbtree_find_or_insert(RBTree *tree, void *entry, bool *inserted);

// Statistics helpers
size_t rbtree_node_count(RBTree *tree);
size_t rbtree_height(RBTree *tree);
void rbtree_print_stats(RBTree *tree);

// Debug & Utility
bool rbtree_verify(RBTree *tree);
void rbtree_print(RBTree *tree, void (*print_entry)(void *entry, int depth));

#define RBT_ENTRY(node, type, member) \
    ((type *)((char *)(node) - offsetof(type, member)))

#define RBTREE_FOREACH(tree, iter) \
    for ((iter) = (tree)->ps_root ? rbtree_min(tree) : NULL; \
         (iter) != NULL; \
         (iter) = rbtree_next(tree, iter))

#define RBTREE_FOREACH_REVERSE(tree, iter) \
    for ((iter) = (tree)->ps_root ? rbtree_max(tree) : NULL; \
         (iter) != NULL; \
         (iter) = rbtree_prev(tree, iter))

#ifdef __cplusplus
}
#endif

#endif // __UTLRBTREE_H__

