#ifndef OSTYPES_H
#define OSTYPES_H

#include <stdint.h>   // For fixed-width integer types
#include <stddef.h>   // For size_t
#include <stdbool.h>  // For bool (optional)

// ─────────────────────────────────────────────
// Variable Naming Convention Guide
// ─────────────────────────────────────────────
//
// Prefix Style:  <prefix><sizeInBytes>_<name>
//
// Examples:
//   u1_id         → unsigned 1-byte (uint8_t)
//   s2_temp       → signed 2-byte (int16_t)
//   u4_flags      → unsigned 4-byte (uint32_t)
//   f4_voltage    → 4-byte float
//   f8_ratio      → 8-byte double
//   ps_task       → pointer to struct task
//   pp_buf        → pointer to pointer (buffer)
//   a_u1_data[10] → array of unsigned 1-byte values
//   p1_msg        → pointer to unsigned 1-byte value
//   b_ready       → boolean flag (can be u1 or bool)
//
// Optional Roles:
//   idx_          → index variable
//   cnt_          → count
//   sz_           → size (in bytes)
//   cb_           → callback function
//
// Use with typedefs below for clarity and consistency
// ──────────────────────────

// ───── Integer Types (Signed/Unsigned) ─────
typedef uint8_t   u1;  // 1-byte unsigned
typedef int8_t    s1;  // 1-byte signed

typedef uint16_t  u2;  // 2-byte unsigned
typedef int16_t   s2;  // 2-byte signed

typedef uint32_t  u4;  // 4-byte unsigned
typedef int32_t   s4;  // 4-byte signed

typedef uint64_t  u8;  // 8-byte unsigned
typedef int64_t   s8;  // 8-byte signed

// ───── Floating-Point Types ─────
typedef float     f4;  // 4-byte float
typedef double    f8;  // 8-byte double

// ───── Boolean Support ─────
#ifndef __cplusplus
#ifndef TRUE
#define TRUE  1
#endif
#ifndef FALSE
#define FALSE 0
#endif
#endif

// ───── Utility Macros ─────
#define ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))
#define UNUSED(x)       (void)(x)

#endif // OSTYPES_H
