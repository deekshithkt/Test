#ifndef __UTLHASH_H__
#define __UTLHASH_H__

#include <stddef.h>
#include <stdbool.h>
#include "utldll.h"

typedef struct {
    DLLHeader *buckets;
    size_t bucket_count;
    size_t offset;
    size_t (*hash_func)(void *entry, size_t bucket_count);
    bool (*key_eq_func)(void *entry, void *key);
} HashTable;

#ifdef __cplusplus
extern "C" {
#endif

bool hash_table_init(HashTable *ht, size_t bucket_count, size_t offset,
                     size_t (*hash_func)(void *, size_t),
                     bool (*key_eq_func)(void *, void *));

void hash_table_insert(HashTable *ht, void *entry);
void* hash_table_find(HashTable *ht, void *key);
void hash_table_remove(HashTable *ht, void *entry);
void hash_table_destroy(HashTable *ht);
size_t hash_table_entry_count(HashTable *ht);
void hash_table_print_stats(HashTable *ht);

#define HASH_TABLE_BUCKET_COUNT(ht) ((ht)->bucket_count)

// Iterate all entries in all buckets
#define HASH_TABLE_FOREACH_ALL(ht, bkt, iter) \
    for (size_t bkt = 0; bkt < (ht)->bucket_count; bkt++) \
        for ((iter) = (ht)->buckets[bkt].ps_head; (iter) != NULL; (iter) = (iter)->ps_next)

#ifdef __cplusplus
}
#endif

#endif // __UTLHASH_H__

