#ifndef __UTLDLL_H__
#define __UTLDLL_H__

#include <stddef.h>
#include <stdbool.h>
#include "ostypes.h"

typedef struct DLLNode {
    struct DLLNode *ps_prev;
    struct DLLNode *ps_next;
} DLLNode;

typedef struct {
    DLLNode *ps_head;
    DLLNode *ps_tail;
    u4       u4_cnt;
    u4       u4_offset;
} DLLHeader;

#ifdef __cplusplus
extern "C" {
#endif

void dll_init(DLLHeader *hdr, size_t offset);
void dll_insert_front(DLLHeader *hdr, void *entry);
void dll_insert_end(DLLHeader *hdr, void *entry);
void dll_remove(DLLHeader *hdr, void *entry);
void* dll_pop_front(DLLHeader *hdr);
void* dll_pop_end(DLLHeader *hdr);
void* dll_find(DLLHeader *hdr, bool (*cmp)(void *entry, void *arg), void *arg);

#define DLL_COUNT(hdr)     ((hdr)->u4_cnt)
#define DLL_FIRST(hdr)     ((hdr)->ps_head)
#define DLL_LAST(hdr)      ((hdr)->ps_tail)

#define DLL_ENTRY(node, type, member) \
    ((type *)((char *)(node) - offsetof(type, member)))

#define DLL_FOREACH(hdr, iter) \
    for ((iter) = (hdr)->ps_head; (iter) != NULL; (iter) = (iter)->ps_next)

#define DLL_FOREACH_REVERSE(hdr, iter) \
    for ((iter) = (hdr)->ps_tail; (iter) != NULL; (iter) = (iter)->ps_prev)

#ifdef __cplusplus
}
#endif

#endif // __UTLDLL_H__

