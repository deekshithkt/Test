#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#include "utlsll.h"

typedef struct MyItem {
    int id;
    char name[32];
    SLLNode node;
} MyItem;

// Comparator function for searching
bool find_by_id(void *pv_entry, void *pv_arg) {
    MyItem *ps_item = (MyItem *)pv_entry;
    int *ps_target_id = (int *)pv_arg;
    return ps_item->id == *ps_target_id;
}

static int s4_tests_passed = 0;
static int s4_tests_failed = 0;

#define START_TEST(id, desc) \
    printf("\nTest Case %s - %s\n", id, desc);

#define END_TEST(cond)                                       \
    do {                                                    \
        if (cond) {                                         \
            printf("Result: PASS\n");                      \
            s4_tests_passed++;                               \
        } else {                                            \
            printf("Result: FAIL\n");                      \
            s4_tests_failed++;                               \
        }                                                   \
    } while (0)

int main() {
    SLLHeader sll_hdr;
    MyItem st_item1 = { .id = 1, .name = "Item1" };
    MyItem st_item2 = { .id = 2, .name = "Item2" };
    MyItem st_item3 = { .id = 3, .name = "Item3" };

    START_TEST("TC01", "Initialize list using sll_init");
    sll_init(&sll_hdr, offsetof(MyItem, node));
    END_TEST(SLL_COUNT(&sll_hdr) == 0 && SLL_FIRST(&sll_hdr) == NULL &&
             SLL_LAST(&sll_hdr) == NULL);

    START_TEST("TC02", "Insert first item using sll_insert_end");
    sll_insert_end(&sll_hdr, &st_item1);
    END_TEST(SLL_COUNT(&sll_hdr) == 1 &&
             SLL_FIRST(&sll_hdr) == &st_item1.node &&
             SLL_LAST(&sll_hdr) == &st_item1.node);

    START_TEST("TC03", "Insert second item using sll_insert_end");
    sll_insert_end(&sll_hdr, &st_item2);
    END_TEST(SLL_COUNT(&sll_hdr) == 2 &&
             SLL_FIRST(&sll_hdr) == &st_item1.node &&
             SLL_LAST(&sll_hdr) == &st_item2.node);

    START_TEST("TC04", "Insert item at front using sll_insert_front");
    sll_insert_front(&sll_hdr, &st_item3); /* Item3 -> Item1 -> Item2 */
    END_TEST(SLL_COUNT(&sll_hdr) == 3 &&
             SLL_FIRST(&sll_hdr) == &st_item3.node &&
             SLL_LAST(&sll_hdr) == &st_item2.node);

    START_TEST("TC05", "Iterate list using SLL_FOREACH to verify order");
    int a_s4_order[3];
    int idx_order = 0;
    SLLNode *ps_iter;
    SLL_FOREACH(&sll_hdr, ps_iter) {
        MyItem *ps_entry = SLL_ENTRY(ps_iter, MyItem, node);
        a_s4_order[idx_order++] = ps_entry->id;
    }
    END_TEST(idx_order == 3 && a_s4_order[0] == 3 && a_s4_order[1] == 1 && a_s4_order[2] == 2);

    START_TEST("TC06", "Find item2 using sll_find");
    int s4_search_id = 2;
    MyItem *ps_found = sll_find(&sll_hdr, find_by_id, &s4_search_id);
    END_TEST(ps_found == &st_item2);

    START_TEST("TC07", "Remove item2 using sll_remove");
    sll_remove(&sll_hdr, &st_item2);
    s4_search_id = 2;
    ps_found = sll_find(&sll_hdr, find_by_id, &s4_search_id);
    END_TEST(SLL_COUNT(&sll_hdr) == 2 &&
             ps_found == NULL &&
             SLL_FIRST(&sll_hdr) == &st_item3.node &&
             SLL_LAST(&sll_hdr) == &st_item1.node);

    START_TEST("TC08", "Pop front item using sll_pop_front");
    MyItem *ps_popped = (MyItem *)sll_pop_front(&sll_hdr);
    END_TEST(ps_popped == &st_item3 &&
             SLL_COUNT(&sll_hdr) == 1 &&
             SLL_FIRST(&sll_hdr) == &st_item1.node &&
             SLL_LAST(&sll_hdr) == &st_item1.node);

    START_TEST("TC09", "Verify remaining count");
    END_TEST(SLL_COUNT(&sll_hdr) == 1);

    // --- Performance Test ---
    typedef struct {
        char name[16];
        SLLNode node;
    } EthIf;

    START_TEST("TC10", "Insert and remove 1000 ethernet interfaces");
    SLLHeader perf_hdr;
    sll_init(&perf_hdr, offsetof(EthIf, node));
    EthIf ifs[1000];
    clock_t start = clock();
    for (int i = 0; i < 1000; i++) {
        snprintf(ifs[i].name, sizeof(ifs[i].name), "ETH%06d", i + 1);
        sll_insert_end(&perf_hdr, &ifs[i]);
    }
    clock_t mid = clock();
    for (int i = 999; i >= 0; i--) {
        sll_remove(&perf_hdr, &ifs[i]);
    }
    clock_t end = clock();
    double insert_ms = (double)(mid - start) * 1000.0 / CLOCKS_PER_SEC;
    double delete_ms = (double)(end - mid) * 1000.0 / CLOCKS_PER_SEC;
    printf("Inserted 1000 and removed in %.2f/%.2f ms\n", insert_ms, delete_ms);
    END_TEST(SLL_COUNT(&perf_hdr) == 0);

    printf("\nConsolidated Test Report:\n");
    printf("Total: %d, Passed: %d, Failed: %d\n",
           s4_tests_passed + s4_tests_failed,
           s4_tests_passed, s4_tests_failed);

    return s4_tests_failed == 0 ? 0 : 1;
}

