# Red-Black Tree (RBTree) API Documentation

## Overview
The Red-Black Tree (RBTree) module provides a generic, self-balancing binary search tree implementation. Red-Black trees guarantee O(log n) time complexity for insertions, deletions, and searches by maintaining balance through node coloring and rotation operations. The implementation uses an intrusive design pattern where the tree node is embedded within user data structures.

## Data Structures

### RBTNode
```c
typedef struct RBTNode {
    struct RBTNode *ps_parent;
    struct RBTNode *ps_left;
    struct RBTNode *ps_right;
    RBTColor        e_color;
} RBTNode;
```
**Description**: Tree node structure that should be embedded in user-defined structures.
- `ps_parent`: Pointer to the parent node
- `ps_left`: Pointer to the left child node
- `ps_right`: Pointer to the right child node
- `e_color`: Node color (RBT_RED or RBT_BLACK)

### RBTColor
```c
typedef enum { RBT_RED, RBT_BLACK } RBTColor;
```
**Description**: Enumeration for node colors used in tree balancing.

### RBTree
```c
typedef struct {
    RBTNode *ps_root;
    u4       u4_offset;
    int     (*pf_compare)(const void *a, const void *b);
} RBTree;
```
**Description**: Main tree structure that manages the root and operations.
- `ps_root`: Pointer to the root node of the tree
- `u4_offset`: Offset of the RBTNode member within the containing structure
- `pf_compare`: User-provided comparison function for ordering elements

## API Functions

### rbtree_init
```c
void rbtree_init(RBTree *tree, size_t offset, int (*cmp)(const void *, const void *));
```
**Description**: Initializes a new red-black tree.

**Parameters**:
- `tree`: Pointer to the RBTree structure to initialize
- `offset`: Offset of the RBTNode member within the containing structure
- `cmp`: Comparison function that returns:
  - < 0 if a < b
  - 0 if a == b
  - > 0 if a > b

**Example**:
```c
typedef struct {
    int id;
    char name[32];
    RBTNode node;
} User;

int compare_users(const void *a, const void *b) {
    return ((User *)a)->id - ((User *)b)->id;
}

RBTree users;
rbtree_init(&users, offsetof(User, node), compare_users);
```

### rbtree_insert
```c
void rbtree_insert(RBTree *tree, void *entry);
```
**Description**: Inserts a new entry into the tree and maintains balance.

**Parameters**:
- `tree`: Pointer to the tree
- `entry`: Pointer to the entry to insert (must contain an embedded RBTNode)

**Time Complexity**: O(log n)

**Note**: Duplicate keys are allowed; duplicates will be placed in the right subtree.

### rbtree_remove
```c
void rbtree_remove(RBTree *tree, void *entry);
```
**Description**: Removes a specific entry from the tree and maintains balance.

**Parameters**:
- `tree`: Pointer to the tree
- `entry`: Pointer to the entry to remove

**Time Complexity**: O(log n)

### rbtree_find
```c
void* rbtree_find(RBTree *tree, void *key);
```
**Description**: Searches for an entry in the tree matching the given key.

**Parameters**:
- `tree`: Pointer to the tree
- `key`: Pointer to the key to search for

**Returns**: Pointer to the found entry, or NULL if not found

**Time Complexity**: O(log n)

**Example**:
```c
User key = {.id = 42};
User *found = rbtree_find(&users, &key);
if (found) {
    printf("Found user: %s\n", found->name);
}
```

### rbtree_min
```c
void* rbtree_min(RBTree *tree);
```
**Description**: Returns the minimum entry in the tree (leftmost node).

**Parameters**:
- `tree`: Pointer to the tree

**Returns**: Pointer to the minimum entry, or NULL if tree is empty

**Time Complexity**: O(log n)

### rbtree_max
```c
void* rbtree_max(RBTree *tree);
```
**Description**: Returns the maximum entry in the tree (rightmost node).

**Parameters**:
- `tree`: Pointer to the tree

**Returns**: Pointer to the maximum entry, or NULL if tree is empty

**Time Complexity**: O(log n)

### rbtree_next
```c
void* rbtree_next(RBTree *tree, void *entry);
```
**Description**: Returns the next entry in sorted order (in-order successor).

**Parameters**:
- `tree`: Pointer to the tree
- `entry`: Pointer to the current entry

**Returns**: Pointer to the next entry, or NULL if no successor exists

**Time Complexity**: O(log n)

### rbtree_prev
```c
void* rbtree_prev(RBTree *tree, void *entry);
```
**Description**: Returns the previous entry in sorted order (in-order predecessor).

**Parameters**:
- `tree`: Pointer to the tree
- `entry`: Pointer to the current entry

**Returns**: Pointer to the previous entry, or NULL if no predecessor exists

**Time Complexity**: O(log n)

### rbtree_lower_bound
```c
void* rbtree_lower_bound(RBTree *tree, void *key);
```
**Description**: Finds the first entry that is not less than the given key.

**Parameters**:
- `tree`: Pointer to the tree
- `key`: Pointer to the search key

**Returns**: Pointer to the entry where entry >= key, or NULL if no such entry exists

**Time Complexity**: O(log n)

### rbtree_upper_bound
```c
void* rbtree_upper_bound(RBTree *tree, void *key);
```
**Description**: Finds the first entry that is greater than the given key.

**Parameters**:
- `tree`: Pointer to the tree
- `key`: Pointer to the search key

**Returns**: Pointer to the entry where entry > key, or NULL if no such entry exists

**Time Complexity**: O(log n)

### rbtree_find_or_insert
```c
void* rbtree_find_or_insert(RBTree *tree, void *entry, bool *inserted);
```
**Description**: Finds an existing entry or inserts a new one if not found.

**Parameters**:
- `tree`: Pointer to the tree
- `entry`: Pointer to the entry to find or insert
- `inserted`: Output parameter set to true if inserted, false if found

**Returns**: Pointer to the found or newly inserted entry

**Time Complexity**: O(log n)

## Statistics Functions

### rbtree_node_count
```c
size_t rbtree_node_count(RBTree *tree);
```
**Description**: Returns the total number of nodes in the tree.

**Parameters**:
- `tree`: Pointer to the tree

**Returns**: Number of nodes

**Time Complexity**: O(n)

### rbtree_height
```c
size_t rbtree_height(RBTree *tree);
```
**Description**: Returns the height of the tree (longest path from root to leaf).

**Parameters**:
- `tree`: Pointer to the tree

**Returns**: Tree height (0 for empty tree)

**Time Complexity**: O(n)

### rbtree_print_stats
```c
void rbtree_print_stats(RBTree *tree);
```
**Description**: Prints detailed statistics about the tree structure.

**Parameters**:
- `tree`: Pointer to the tree

**Output**: Displays node count, height, and balance information

## Debug Functions

### rbtree_verify
```c
bool rbtree_verify(RBTree *tree);
```
**Description**: Verifies that the tree maintains all Red-Black properties.

**Parameters**:
- `tree`: Pointer to the tree

**Returns**: true if valid Red-Black tree, false otherwise

**Red-Black Properties Verified**:
1. Every node is either red or black
2. Root is black
3. All leaves (NULL nodes) are black
4. Red nodes have only black children
5. All paths from root to leaves contain the same number of black nodes

### rbtree_print
```c
void rbtree_print(RBTree *tree, void (*print_entry)(void *entry, int depth));
```
**Description**: Prints the tree structure with user-defined entry printing.

**Parameters**:
- `tree`: Pointer to the tree
- `print_entry`: Function to print an entry at given depth

**Example**:
```c
void print_user(void *entry, int depth) {
    User *u = (User *)entry;
    RBTNode *n = &u->node;
    printf("%*s[%d] %s (%s)\n", depth * 2, "", u->id, u->name,
           n->e_color == RBT_RED ? "R" : "B");
}

rbtree_print(&users, print_user);
```

## Macros

### RBT_ENTRY
```c
#define RBT_ENTRY(node, type, member) \
    ((type *)((char *)(node) - offsetof(type, member)))
```
**Description**: Converts an RBTNode pointer to its containing structure.

**Parameters**:
- `node`: Pointer to the RBTNode
- `type`: Type of the containing structure
- `member`: Name of the RBTNode member within the structure

**Returns**: Pointer to the containing structure

### RBTREE_FOREACH
```c
#define RBTREE_FOREACH(tree, iter) \
    for ((iter) = (tree)->ps_root ? rbtree_min(tree) : NULL; \
         (iter) != NULL; \
         (iter) = rbtree_next(tree, iter))
```
**Description**: Iterates through all entries in ascending order.

**Parameters**:
- `tree`: Pointer to the tree
- `iter`: Iterator variable (pointer to entry type)

**Example**:
```c
User *user;
RBTREE_FOREACH(&users, user) {
    printf("ID: %d, Name: %s\n", user->id, user->name);
}
```

### RBTREE_FOREACH_REVERSE
```c
#define RBTREE_FOREACH_REVERSE(tree, iter) \
    for ((iter) = (tree)->ps_root ? rbtree_max(tree) : NULL; \
         (iter) != NULL; \
         (iter) = rbtree_prev(tree, iter))
```
**Description**: Iterates through all entries in descending order.

**Parameters**:
- `tree`: Pointer to the tree
- `iter`: Iterator variable (pointer to entry type)

## Usage Example

```c
#include "utlrbtree.h"
#include <stdio.h>
#include <string.h>

typedef struct {
    int score;
    char player[32];
    time_t timestamp;
    RBTNode node;
} GameScore;

int compare_scores(const void *a, const void *b) {
    const GameScore *sa = (const GameScore *)a;
    const GameScore *sb = (const GameScore *)b;
    
    // Higher scores first
    if (sa->score != sb->score)
        return sb->score - sa->score;
    
    // Then by timestamp (earlier first)
    return (int)(sa->timestamp - sb->timestamp);
}

int main() {
    RBTree leaderboard;
    
    // Initialize the tree
    rbtree_init(&leaderboard, offsetof(GameScore, node), compare_scores);
    
    // Add scores
    GameScore scores[] = {
        {1000, "Alice", time(NULL), {0}},
        {1500, "Bob", time(NULL) + 1, {0}},
        {1000, "Charlie", time(NULL) + 2, {0}},
        {2000, "Dave", time(NULL) + 3, {0}},
        {1500, "Eve", time(NULL) + 4, {0}}
    };
    
    for (int i = 0; i < 5; i++) {
        rbtree_insert(&leaderboard, &scores[i]);
    }
    
    // Print leaderboard
    printf("Leaderboard:\n");
    int rank = 1;
    GameScore *score;
    RBTREE_FOREACH(&leaderboard, score) {
        printf("%d. %s - %d points\n", rank++, score->player, score->score);
    }
    
    // Find scores in range [1000, 1500]
    printf("\nScores between 1000-1500:\n");
    GameScore lower_key = {1000, "", 0, {0}};
    GameScore upper_key = {1500, "", 0, {0}};
    
    score = rbtree_lower_bound(&leaderboard, &upper_key);
    while (score && score->score >= 1000) {
        printf("  %s - %d points\n", score->player, score->score);
        score = rbtree_next(&leaderboard, score);
    }
    
    // Verify tree integrity
    if (rbtree_verify(&leaderboard)) {
        printf("\nTree integrity: OK\n");
    }
    
    // Print statistics
    rbtree_print_stats(&leaderboard);
    
    return 0;
}
```

## Key Features

1. **Self-Balancing**: Automatically maintains balance through red-black properties
2. **Ordered Traversal**: Supports efficient in-order traversal in both directions
3. **Range Queries**: Provides lower_bound and upper_bound for range searches
4. **Guaranteed Performance**: O(log n) worst-case for all basic operations
5. **Intrusive Design**: Zero allocation overhead for tree operations

## Design Considerations

### Comparison Function
The comparison function must:
- Be consistent: if a < b and b < c, then a < c
- Be deterministic: same inputs always produce same result
- Handle all fields that determine ordering
- Return negative for less than, zero for equal, positive for greater than

### Memory Management
- The tree does not allocate memory for entries
- Users are responsible for entry lifetime management
- Entries must remain valid while in the tree
- The tree only manages pointers and node colors

### Performance Characteristics
- Height is guaranteed to be at most 2 * log(n+1)
- All operations complete in O(log n) time
- Iteration is O(1) amortized per element
- No memory allocation during operations

## Notes
- The implementation uses the intrusive pattern - RBTNode must be embedded in your structure
- Thread safety is not provided - external synchronization required for concurrent access
- Duplicate keys are supported and placed in the right subtree
- The tree maintains strict weak ordering based on the comparison function
- NULL entries are not supported
- For best performance, ensure the comparison function is efficient